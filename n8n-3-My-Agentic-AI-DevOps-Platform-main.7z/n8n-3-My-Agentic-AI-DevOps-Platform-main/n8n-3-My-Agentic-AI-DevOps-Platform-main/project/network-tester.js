#!/usr/bin/env node

/**
 * Network Connectivity Tester for MCP DevOps Server
 * 
 * This script tests network connectivity to various services used by the MCP server.
 * It helps diagnose ECONNRESET, ECONNREFUSED and other network issues.
 */

const https = require('https');
const http = require('http');
const fs = require('fs');
const path = require('path');
const dotenv = require('dotenv');
const axios = require('axios');

// Load environment variables from .env file if it exists
const envPath = path.join(__dirname, '.env');
if (fs.existsSync(envPath)) {
  dotenv.config({ path: envPath });
  console.log('✅ Found .env file and loaded environment variables');
} else {
  console.log('⚠️ No .env file found, using environment variables from the system');
}

// Terminal colors for better readability
const colors = {
  reset: '\x1b[0m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  magenta: '\x1b[35m',
  cyan: '\x1b[36m',
  bold: '\x1b[1m'
};

function printHeader(text) {
  console.log(`\n${colors.bold}${colors.blue}=== ${text} ===${colors.reset}\n`);
}

function printSuccess(text) {
  console.log(`${colors.green}✅ ${text}${colors.reset}`);
}

function printError(text) {
  console.log(`${colors.red}❌ ${text}${colors.reset}`);
}

function printWarning(text) {
  console.log(`${colors.yellow}⚠️ ${text}${colors.reset}`);
}

function printInfo(text) {
  console.log(`${colors.cyan}ℹ️ ${text}${colors.reset}`);
}

// Test HTTP/HTTPS connectivity to a specific URL
async function testEndpoint(url, description, options = {}) {
  const isHttps = url.startsWith('https');
  const client = isHttps ? https : http;
  
  return new Promise((resolve) => {
    const reqOptions = {
      method: options.method || 'HEAD',
      headers: {}
    };
    
    if (options.token) {
      reqOptions.headers.Authorization = `Bearer ${options.token}`;
    }
    
    const req = client.request(url, reqOptions, (res) => {
      printSuccess(`${description} is accessible (Status: ${res.statusCode} ${res.statusMessage})`);
      resolve({
        success: true,
        statusCode: res.statusCode,
        headers: res.headers
      });
    });
    
    req.on('error', (error) => {
      if (error.code === 'ECONNRESET') {
        printError(`Connection reset error when connecting to ${description}: ${error.message}`);
        printInfo(`This is likely due to a network issue or service rejecting the connection`);
      } else if (error.code === 'ECONNREFUSED') {
        printError(`Connection refused by ${description}: ${error.message}`);
        printInfo(`The service is either down or not accepting connections on that port`);
      } else {
        printError(`Cannot connect to ${description}: ${error.message}`);
      }
      
      resolve({
        success: false,
        error: error.message,
        code: error.code
      });
    });
    
    req.setTimeout(5000, () => {
      req.destroy(new Error('Request timed out'));
      printError(`Connection to ${description} timed out after 5 seconds`);
      resolve({
        success: false,
        error: 'Request timed out',
        code: 'ETIMEDOUT'
      });
    });
    
    req.end();
  });
}

// Test GitHub API connectivity specifically
async function testGitHubAPI() {
  printHeader('TESTING GITHUB API CONNECTIVITY');
  
  const githubToken = process.env.GITHUB_TOKEN;
  
  if (!githubToken) {
    printError('No GITHUB_TOKEN environment variable found');
    printInfo('This is a critical environment variable for GitHub API access');
    printInfo('Set this variable in your .env file or environment before proceeding');
    return false;
  }
  
  printInfo('Testing connection to GitHub API with your token...');
  
  const result = await testEndpoint('https://api.github.com/user', 'GitHub API', {
    method: 'GET',
    token: githubToken
  });
  
  if (!result.success) {
    printError('GitHub API connection failed');
    printInfo('This will cause ECONNRESET errors when trying to fetch PR diffs or other GitHub data');
    return false;
  }
  
  if (result.statusCode === 401) {
    printError('GitHub token is invalid or expired');
    printInfo('Please generate a new Personal Access Token with repo scope');
    return false;
  }
  
  return true;
}

// Test local MCP server
async function testLocalServer() {
  printHeader('TESTING LOCAL MCP SERVER');
  
  const port = process.env.PORT || 3000;
  const url = `http://localhost:${port}/health`;
  
  printInfo(`Testing connection to local MCP server on port ${port}...`);
  
  try {
    await testEndpoint(url, 'Local MCP server');
    return true;
  } catch (error) {
    printWarning(`Local server may not be running or doesn't have a /health endpoint`);
    printInfo(`Try starting your server with: node server.js`);
    return false;
  }
}

// Test authentication with MCP server
async function testAuthentication() {
  printHeader('TESTING MCP SERVER AUTHENTICATION');
  
  const token = process.env.MCP_SERVER_TOKEN;
  const hardcodedToken = 'AmuvuMwmyuir9kaQX9VE9rpIXMuE2hc4kSC9RyJpXhg';
  
  if (!token) {
    printWarning('No MCP_SERVER_TOKEN environment variable found');
    printInfo(`Using hardcoded token: ${hardcodedToken.substring(0, 3)}...${hardcodedToken.substring(hardcodedToken.length - 3)}`);
  }
  
  const port = process.env.PORT || 3000;
  const url = `http://localhost:${port}/api/v1/agents/health`;
  
  printInfo('Testing authentication with token...');
  
  try {
    // First try with environment variable token
    if (token) {
      const result = await axios.get(url, {
        headers: { Authorization: `Bearer ${token}` }
      });
      printSuccess('Authentication successful with MCP_SERVER_TOKEN');
      return true;
    }
    
    // Then try with hardcoded token
    const result = await axios.get(url, {
      headers: { Authorization: `Bearer ${hardcodedToken}` }
    });
    printSuccess('Authentication successful with hardcoded token');
    return true;
  } catch (error) {
    if (error.response) {
      printError(`Authentication failed with status ${error.response.status}: ${error.response.data.error || error.message}`);
    } else {
      printError(`Authentication test failed: ${error.message}`);
    }
    
    printInfo('Check that your server is running and the auth middleware is configured correctly');
    return false;
  }
}

// Test LLM API connections
async function testLLMAPIs() {
  printHeader('TESTING LLM API CONNECTIVITY');
  
  const openaiKey = process.env.OPENAI_API_KEY;
  const anthropicKey = process.env.ANTHROPIC_API_KEY;
  let anySuccessful = false;
  
  if (!openaiKey && !anthropicKey) {
    printWarning('No LLM API keys found (OPENAI_API_KEY, ANTHROPIC_API_KEY)');
    printInfo('At least one LLM API key is recommended for code analysis features');
  }
  
  if (openaiKey) {
    printInfo('Testing connection to OpenAI API...');
    const result = await testEndpoint('https://api.openai.com/v1/models', 'OpenAI API', {
      method: 'GET',
      token: openaiKey
    });
    if (result.success && result.statusCode !== 401) {
      anySuccessful = true;
    }
  }
  
  if (anthropicKey) {
    printInfo('Testing connection to Anthropic API...');
    const result = await testEndpoint('https://api.anthropic.com/v1/messages', 'Anthropic API', {
      method: 'GET',
      token: anthropicKey
    });
    if (result.success && result.statusCode !== 401) {
      anySuccessful = true;
    }
  }
  
  return anySuccessful;
}

// Run all the tests
async function runTests() {
  printHeader('NETWORK CONNECTIVITY TESTER FOR MCP DEVOPS SERVER');
  printInfo('This script checks for common connectivity issues that might cause ECONNRESET errors');
  
  let allPassed = true;
  
  // Internet connectivity check
  const internetResult = await testEndpoint('https://www.google.com', 'Internet connection');
  if (!internetResult.success) {
    printError('No internet connection detected. Please check your network settings.');
    return;
  }
  
  // GitHub API test
  const githubPassed = await testGitHubAPI();
  allPassed = allPassed && githubPassed;
  
  // Local server test
  const serverPassed = await testLocalServer();
  if (!serverPassed) {
    printWarning('Local server test skipped (server may not be running)');
  }
  
  // LLM API test
  const llmPassed = await testLLMAPIs();
  if (!llmPassed) {
    printWarning('LLM API connectivity issues detected. Some code analysis features may not work.');
    allPassed = false;
  }
  
  // Summary
  printHeader('TEST RESULTS SUMMARY');
  if (allPassed) {
    printSuccess('All critical connectivity tests passed!');
    printInfo('If you were experiencing ECONNRESET errors, they should be resolved now.');
  } else {
    printWarning('Some connectivity tests failed.');
    printInfo('Please address the issues above to resolve ECONNRESET errors.');
    
    printHeader('TROUBLESHOOTING SUGGESTIONS');
    
    if (!githubPassed) {
      printInfo('1. Generate a new GitHub Personal Access Token with "repo" scope');
      printInfo('   - Visit: https://github.com/settings/tokens');
      printInfo('   - Add the new token to your .env file as GITHUB_TOKEN=your-token');
    }
    
    if (!llmPassed) {
      printInfo('2. Check your OpenAI or Anthropic API keys');
      printInfo('   - OpenAI: https://platform.openai.com/account/api-keys');
      printInfo('   - Anthropic: https://console.anthropic.com/settings/keys');
    }
    
    printInfo('3. Run this script again after making changes to verify the connections');
  }
}

// Run the tests
runTests().catch(error => {
  printError(`An unexpected error occurred: ${error.message}`);
  console.error(error);
});
