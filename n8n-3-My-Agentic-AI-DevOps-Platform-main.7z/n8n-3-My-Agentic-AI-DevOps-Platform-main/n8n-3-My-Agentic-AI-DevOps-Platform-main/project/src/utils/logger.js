const winston = require('winston');
const fs = require('fs');
const path = require('path');

// Make sure logs directory exists
const logDir = path.join(process.cwd(), 'logs');
if (!fs.existsSync(logDir)) {
  fs.mkdirSync(logDir);
}

// Custom format for better network error logging
const networkErrorFormat = winston.format((info) => {
  if (info.error) {
    if (info.error.code === 'ECONNRESET' || 
        info.error.code === 'ECONNREFUSED' || 
        info.error.code === 'ETIMEDOUT') {
      info.network_error = true;
      info.network_error_code = info.error.code;
      info.network_error_details = {
        host: info.error.address || 'unknown',
        port: info.error.port || 'unknown',
        timestamp: new Date().toISOString()
      };
    }
  }
  return info;
});

const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || 'info',
  format: winston.format.combine(
    networkErrorFormat(),
    winston.format.timestamp(),
    winston.format.errors({ stack: true }),
    winston.format.json()
  ),
  defaultMeta: { 
    service: 'mcp-devops-server',
    server_ip: '51.57.62.137',  // Your server's IP for correlation
    version: process.env.APP_VERSION || '1.0.0'
  },
  transports: [
    new winston.transports.File({ 
      filename: 'logs/error.log', 
      level: 'error',
      maxsize: 10485760,  // 10MB
      maxFiles: 5
    }),
    new winston.transports.File({ 
      filename: 'logs/network_errors.log',
      level: 'warn',
      format: winston.format.combine(
        winston.format((info) => info.network_error ? info : false)(),
        winston.format.timestamp(),
        winston.format.json()
      )
    }),
    new winston.transports.File({ 
      filename: 'logs/combined.log',
      maxsize: 10485760,  // 10MB
      maxFiles: 5
    }),
  ],
  exceptionHandlers: [
    new winston.transports.File({ filename: 'logs/exceptions.log' })
  ]
});

if (process.env.NODE_ENV !== 'production') {
  logger.add(new winston.transports.Console({
    format: winston.format.combine(
      winston.format.colorize(),
      winston.format.simple()
    ),
    handleExceptions: true
  }));
}

// Add convenience methods for network errors
logger.networkError = (message, error, additionalInfo = {}) => {
  logger.error(message, { 
    error, 
    network_error: true,
    ...additionalInfo
  });
};

module.exports = logger;