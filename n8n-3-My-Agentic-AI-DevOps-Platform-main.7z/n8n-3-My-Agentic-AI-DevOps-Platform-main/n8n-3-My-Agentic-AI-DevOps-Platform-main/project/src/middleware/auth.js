const jwt = require('jsonwebtoken');
const logger = require('../utils/logger');

const authMiddleware = (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    
    // Hardcoded token for your specific token
    const hardcodedToken = 'AmuvuMwmyuir9kaQX9VE9rpIXMuE2hc4kSC9RyJpXhg';
    
    // Log the token information for debugging (remove in production)
    logger.info('Auth middleware processing request', {
      hasAuthHeader: !!authHeader,
      tokenFormat: authHeader && authHeader.startsWith('Bearer ') ? 'Bearer format' : 'Invalid format',
      serverTokenSet: !!process.env.MCP_SERVER_TOKEN
    });
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      logger.warn('Missing or invalid authorization header');
      return res.status(401).json({
        error: 'Access denied. No token provided or invalid format.',
        expected_format: 'Bearer <token>',
        received_header: authHeader ? 'Bearer ***' : 'none'
      });
    }

    const token = authHeader.substring(7);
    
    if (!token || token.trim().length === 0) {
      logger.warn('Empty token provided');
      return res.status(401).json({
        error: 'Access denied. Empty token provided.',
        expected_format: 'Bearer <token>'
      });
    }
    
    // Accept hardcoded token (your specific n8n workflow token)
    if (token === hardcodedToken) {
      req.user = { id: 'system', role: 'admin' };
      logger.info('Request authorized with hardcoded token');
      return next();
    }
    
    // For development, allow environment variable token
    if (process.env.MCP_SERVER_TOKEN && token === process.env.MCP_SERVER_TOKEN) {
      req.user = { id: 'system', role: 'admin' };
      logger.info('Request authorized with environment token');
      return next();
    }

    // Try to verify as JWT token
    try {
      if (process.env.JWT_SECRET) {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        req.user = decoded;
        logger.info('Request authorized with JWT token');
        return next();
      } else {
        logger.warn('JWT_SECRET not configured, skipping JWT verification');
      }
    } catch (jwtError) {
      logger.warn('JWT verification failed', { error: jwtError.message });
    }
    
    // If we got here, no authentication method worked
    logger.error('Authentication failed - no valid authentication method');
    return res.status(401).json({
      error: 'Access denied. Invalid token.',
      tip: 'Ensure you are using the correct token format: Bearer <token>'
    });
  } catch (error) {
    logger.error('Authentication error:', error);
    res.status(401).json({
      error: 'Invalid token',
      message: error.message,
      hint: 'Make sure you are using the correct MCP_SERVER_TOKEN or a valid JWT token'
    });
  }
};

module.exports = authMiddleware;