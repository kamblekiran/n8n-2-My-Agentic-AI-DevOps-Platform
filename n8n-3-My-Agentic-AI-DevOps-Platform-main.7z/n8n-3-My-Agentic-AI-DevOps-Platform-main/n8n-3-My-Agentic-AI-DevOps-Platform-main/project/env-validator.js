#!/usr/bin/env node

/**
 * Environment Variable Validator for MCP DevOps Server
 * 
 * This script validates that all required environment variables are set
 * and have appropriate values. Run this script before starting your server
 * to check for any configuration issues.
 */

const fs = require('fs');
const path = require('path');
const dotenv = require('dotenv');

// Load environment variables from .env file if it exists
const envPath = path.join(__dirname, '.env');
if (fs.existsSync(envPath)) {
  dotenv.config({ path: envPath });
  console.log('✅ Found .env file and loaded environment variables');
} else {
  console.log('⚠️ No .env file found, using environment variables from the system');
}

// Define required environment variables
const requiredVariables = [
  { name: 'MCP_SERVER_TOKEN', critical: true, hint: 'Used for API authentication' },
  { name: 'GITHUB_TOKEN', critical: true, hint: 'Required for GitHub API access' },
  { name: 'JWT_SECRET', critical: false, hint: 'Used for JWT token signing' },
  { name: 'OPENAI_API_KEY', critical: false, hint: 'Required if using OpenAI models' },
  { name: 'ANTHROPIC_API_KEY', critical: false, hint: 'Required if using Anthropic models' },
];

// Define optional but recommended variables
const recommendedVariables = [
  { name: 'PORT', defaultValue: '3000', hint: 'Server port' },
  { name: 'NODE_ENV', defaultValue: 'development', hint: 'Environment mode' },
  { name: 'DEFAULT_LLM_MODEL', defaultValue: 'gpt-3.5-turbo', hint: 'Default LLM model' },
  { name: 'LOG_LEVEL', defaultValue: 'info', hint: 'Logging verbosity' },
];

// Check required variables
let criticalMissing = false;
let nonCriticalMissing = false;

console.log('\n=== REQUIRED ENVIRONMENT VARIABLES ===');
for (const variable of requiredVariables) {
  const value = process.env[variable.name];
  if (!value) {
    if (variable.critical) {
      console.log(`❌ CRITICAL: ${variable.name} is not set. ${variable.hint}`);
      criticalMissing = true;
    } else {
      console.log(`⚠️ MISSING: ${variable.name} is not set. ${variable.hint}`);
      nonCriticalMissing = true;
    }
  } else {
    const maskedValue = variable.name.includes('TOKEN') || variable.name.includes('KEY') || variable.name.includes('SECRET')
      ? value.substring(0, 3) + '...' + value.substring(value.length - 3)
      : value;
    console.log(`✅ ${variable.name}: ${maskedValue}`);
  }
}

// Check recommended variables
console.log('\n=== RECOMMENDED ENVIRONMENT VARIABLES ===');
for (const variable of recommendedVariables) {
  const value = process.env[variable.name];
  if (!value) {
    console.log(`ℹ️ ${variable.name} is not set. Using default: ${variable.defaultValue}. ${variable.hint}`);
  } else {
    console.log(`✅ ${variable.name}: ${value}`);
  }
}

// Check network connectivity
console.log('\n=== NETWORK CONNECTIVITY ===');
const https = require('https');

function checkEndpoint(url, description) {
  return new Promise((resolve) => {
    const req = https.request(url, { method: 'HEAD' }, (res) => {
      console.log(`✅ ${description} is accessible (${res.statusCode})`);
      resolve(true);
    });
    
    req.on('error', (error) => {
      console.log(`❌ Cannot connect to ${description}: ${error.message}`);
      resolve(false);
    });
    
    req.setTimeout(3000, () => {
      req.destroy(new Error('Request timed out'));
      console.log(`❌ Connection to ${description} timed out`);
      resolve(false);
    });
    
    req.end();
  });
}

async function runNetworkChecks() {
  await checkEndpoint('https://api.github.com', 'GitHub API');
  
  if (process.env.OPENAI_API_KEY) {
    await checkEndpoint('https://api.openai.com', 'OpenAI API');
  }
  
  if (process.env.ANTHROPIC_API_KEY) {
    await checkEndpoint('https://api.anthropic.com', 'Anthropic API');
  }
  
  // Summary
  console.log('\n=== VALIDATION SUMMARY ===');
  if (criticalMissing) {
    console.log('❌ CRITICAL VARIABLES MISSING: The application will not function correctly without these variables.');
    console.log('   Please set them in your .env file or environment before starting the server.');
  } else if (nonCriticalMissing) {
    console.log('⚠️ Some non-critical variables are missing. The application may function with limited capabilities.');
  } else {
    console.log('✅ All required environment variables are set.');
  }
  
  console.log('\nFor reference, check the .env.example file for all configurable options.');
}

runNetworkChecks();
